import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 * Filtro para el campo Pasaporte.
 * Formato: 1 letra (A-Z) seguida de hasta 8 dígitos numéricos. Total: 9 caracteres.
 * Ejemplo: N39392288
 */
public class FiltroPasaporte extends DocumentFilter {

    private static final int MAX_LONGITUD = 9; // 1 letra + 8 dígitos

    @Override
    public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
            throws BadLocationException {
        if (string == null) return;
        String docActual = fb.getDocument().getText(0, fb.getDocument().getLength());
        String nuevo = docActual.substring(0, offset) + string + docActual.substring(offset);
        if (esValido(nuevo)) {
            super.insertString(fb, offset, string.toUpperCase(), attr);
        }
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
            throws BadLocationException {
        if (text == null) text = "";
        String docActual = fb.getDocument().getText(0, fb.getDocument().getLength());
        String nuevo = docActual.substring(0, offset) + text + docActual.substring(offset + length);
        if (esValido(nuevo)) {
            super.replace(fb, offset, length, text.toUpperCase(), attrs);
        }
    }

    /**
     * Valida que la cadena cumpla el formato del pasaporte durante la escritura:
     * - Posición 0: debe ser una letra (A-Z)
     * - Posiciones 1-8: deben ser dígitos
     * - Longitud máxima: 9
     */
    private boolean esValido(String texto) {
        if (texto.length() > MAX_LONGITUD) return false;
        for (int i = 0; i < texto.length(); i++) {
            char c = texto.charAt(i);
            if (i == 0) {
                if (!Character.isLetter(c)) return false;
            } else {
                if (!Character.isDigit(c)) return false;
            }
        }
        return true;
    }
}
