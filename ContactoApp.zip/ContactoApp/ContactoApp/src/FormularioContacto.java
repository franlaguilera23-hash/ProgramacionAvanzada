import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.AbstractDocument;
import java.awt.*;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

/**
 * Formulario principal de "Carga de Contacto".
 * Trabajo Práctico N°1 - Programación Avanzada - UDA
 * Tema: Librería Swing - Formularios y validaciones
 */
public class FormularioContacto extends JFrame {

    // ── Campos del formulario ──────────────────────────────────────────────
    private JTextField txtNombre;
    private JTextField txtApellido;
    private JTextField txtDni;
    private JTextField txtPasaporte;
    private JTextField txtTelefono;
    private JTextField txtCodigoPostal;
    private JTextField txtDomicilio;

    // ── Etiquetas de error (una por campo) ────────────────────────────────
    private JLabel lblErrorNombre;
    private JLabel lblErrorApellido;
    private JLabel lblErrorDni;
    private JLabel lblErrorPasaporte;
    private JLabel lblErrorTelefono;
    private JLabel lblErrorCodigoPostal;
    private JLabel lblErrorDomicilio;

    // ── Colores ───────────────────────────────────────────────────────────
    private static final Color COLOR_ERROR   = new Color(200, 0, 0);
    private static final Color COLOR_OK      = new Color(0, 130, 0);
    private static final Color COLOR_BORDE_ERROR = new Color(220, 60, 60);
    private static final Color COLOR_BORDE_OK    = new Color(60, 160, 60);
    private static final Color COLOR_BORDE_NORMAL = new Color(180, 180, 180);

    public FormularioContacto() {
        inicializarVentana();
        inicializarComponentes();
        configurarFiltros();
        configurarValidacionFuera();
        configurarMutualExclusion();
    }

    // ── 1. Configuración de la ventana ────────────────────────────────────

    private void inicializarVentana() {
        setTitle("Carga de Contacto");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setResizable(false);
        setLocationRelativeTo(null);
    }

    // ── 2. Construcción de la interfaz ────────────────────────────────────

    private void inicializarComponentes() {
        JPanel panelPrincipal = new JPanel(new BorderLayout(10, 10));
        panelPrincipal.setBorder(new EmptyBorder(15, 20, 15, 20));

        // Panel de campos
        JPanel panelCampos = new JPanel(new GridBagLayout());
        TitledBorder tituloBorde = BorderFactory.createTitledBorder("Carga de Contacto");
        tituloBorde.setTitleFont(new Font("SansSerif", Font.BOLD, 14));
        panelCampos.setBorder(BorderFactory.createCompoundBorder(
                tituloBorde,
                new EmptyBorder(10, 10, 10, 10)
        ));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 2, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;

        // Crear campos
        txtNombre       = crearTextField(20);
        txtApellido     = crearTextField(20);
        txtDni          = crearTextField(10);
        txtPasaporte    = crearTextField(10);
        txtTelefono     = crearTextField(20);
        txtCodigoPostal = crearTextField(6);
        txtDomicilio    = crearTextField(30);

        // Crear labels de error
        lblErrorNombre       = crearLabelError();
        lblErrorApellido     = crearLabelError();
        lblErrorDni          = crearLabelError();
        lblErrorPasaporte    = crearLabelError();
        lblErrorTelefono     = crearLabelError();
        lblErrorCodigoPostal = crearLabelError();
        lblErrorDomicilio    = crearLabelError();

        // Agregar filas al panel
        int fila = 0;
        agregarFila(panelCampos, gbc, fila++, "Nombre:",
                txtNombre, lblErrorNombre, "(máx. 20 caracteres alfabéticos)");
        agregarFila(panelCampos, gbc, fila++, "Apellido:",
                txtApellido, lblErrorApellido, "(máx. 20 caracteres alfabéticos)");
        agregarFila(panelCampos, gbc, fila++, "DNI:",
                txtDni, lblErrorDni, "(8 dígitos, entre 10.000.000 y 60.000.000)");
        agregarFila(panelCampos, gbc, fila++, "Pasaporte:",
                txtPasaporte, lblErrorPasaporte, "(1 letra A-Z + 8 dígitos, ej: N39392288)");
        agregarFila(panelCampos, gbc, fila++, "Teléfono:",
                txtTelefono, lblErrorTelefono, "(>6 dígitos y + ( ) - , ej: +54 9 (261)-5-012345)");
        agregarFila(panelCampos, gbc, fila++, "Código Postal:",
                txtCodigoPostal, lblErrorCodigoPostal, "(4 dígitos numéricos)");
        agregarFila(panelCampos, gbc, fila++, "Domicilio:",
                txtDomicilio, lblErrorDomicilio, "(máx. 50 caracteres)");

        // Panel de botones
        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new FlowLayout(FlowLayout.CENTER, 15, 5));

        JButton btnValidar  = crearBoton("Validar",  new Color(0, 100, 180));
        JButton btnLimpiar  = crearBoton("Limpiar",  new Color(100, 100, 100));
        JButton btnCerrar   = crearBoton("Cerrar",   new Color(180, 40, 40));

        btnValidar.addActionListener(e -> validarFormulario());
        btnLimpiar.addActionListener(e -> limpiarFormulario());
        btnCerrar.addActionListener(e -> System.exit(0));

        panelBotones.add(btnValidar);
        panelBotones.add(btnLimpiar);

        JPanel panelCerrar = new JPanel(new FlowLayout(FlowLayout.CENTER));
        panelCerrar.add(btnCerrar);

        JPanel panelSur = new JPanel(new BorderLayout());
        panelSur.add(panelBotones, BorderLayout.CENTER);
        panelSur.add(panelCerrar, BorderLayout.SOUTH);

        panelPrincipal.add(panelCampos, BorderLayout.CENTER);
        panelPrincipal.add(panelSur, BorderLayout.SOUTH);

        setContentPane(panelPrincipal);
        pack();
        setMinimumSize(new Dimension(580, 0));
        setLocationRelativeTo(null);
    }

    /** Agrega una fila de: etiqueta | campo | hint + error al GridBagLayout. */
    private void agregarFila(JPanel panel, GridBagConstraints gbc,
                              int fila, String etiqueta,
                              JTextField campo, JLabel labelError, String hint) {
        // Etiqueta
        gbc.gridx = 0; gbc.gridy = fila * 2;
        gbc.weightx = 0;
        gbc.gridwidth = 1;
        JLabel lbl = new JLabel(etiqueta);
        lbl.setFont(new Font("SansSerif", Font.BOLD, 12));
        panel.add(lbl, gbc);

        // Campo
        gbc.gridx = 1; gbc.gridy = fila * 2;
        gbc.weightx = 1;
        panel.add(campo, gbc);

        // Hint
        gbc.gridx = 2; gbc.gridy = fila * 2;
        gbc.weightx = 0;
        JLabel lblHint = new JLabel(hint);
        lblHint.setFont(new Font("SansSerif", Font.ITALIC, 10));
        lblHint.setForeground(new Color(120, 120, 120));
        panel.add(lblHint, gbc);

        // Label de error (fila siguiente, columna del campo)
        gbc.gridx = 1; gbc.gridy = fila * 2 + 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1;
        panel.add(labelError, gbc);
        gbc.gridwidth = 1;
    }

    // ── 3. Helpers de creación de componentes ─────────────────────────────

    private JTextField crearTextField(int columnas) {
        JTextField tf = new JTextField(columnas);
        tf.setFont(new Font("Monospaced", Font.PLAIN, 13));
        tf.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDE_NORMAL, 1, true),
                new EmptyBorder(3, 5, 3, 5)
        ));
        return tf;
    }

    private JLabel crearLabelError() {
        JLabel lbl = new JLabel(" ");
        lbl.setFont(new Font("SansSerif", Font.PLAIN, 10));
        lbl.setForeground(COLOR_ERROR);
        lbl.setPreferredSize(new Dimension(200, 14));
        return lbl;
    }

    private JButton crearBoton(String texto, Color colorFondo) {
        JButton btn = new JButton(texto);
        btn.setBackground(colorFondo);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("SansSerif", Font.BOLD, 12));
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(colorFondo.darker(), 1, true),
                new EmptyBorder(6, 20, 6, 20)
        ));
        btn.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return btn;
    }

    // ── 4. Filtros a nivel de carácter (dentro del campo) ─────────────────

    private void configurarFiltros() {
        // Nombre: solo letras, máx 20
        ((AbstractDocument) txtNombre.getDocument())
                .setDocumentFilter(new FiltroAlfabetico(20));

        // Apellido: solo letras, máx 20
        ((AbstractDocument) txtApellido.getDocument())
                .setDocumentFilter(new FiltroAlfabetico(20));

        // DNI: solo dígitos, máx 8
        ((AbstractDocument) txtDni.getDocument())
                .setDocumentFilter(new FiltroNumerico(8));

        // Pasaporte: 1 letra + 8 dígitos
        ((AbstractDocument) txtPasaporte.getDocument())
                .setDocumentFilter(new FiltroPasaporte());

        // Teléfono: dígitos y +()-
        ((AbstractDocument) txtTelefono.getDocument())
                .setDocumentFilter(new FiltroTelefono());

        // Código Postal: solo dígitos, máx 4
        ((AbstractDocument) txtCodigoPostal.getDocument())
                .setDocumentFilter(new FiltroNumerico(4));

        // Domicilio: máx 50 (sin filtro de tipo, cualquier carácter)
        ((AbstractDocument) txtDomicilio.getDocument())
                .setDocumentFilter(new FiltroMaxLength(50));
    }

    // ── 5. Validación al salir del campo (FocusLost) ──────────────────────

    private void configurarValidacionFuera() {
        // Nombre
        txtNombre.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { validarNombre(); }
        });
        // Apellido
        txtApellido.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { validarApellido(); }
        });
        // DNI
        txtDni.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                validarDni();
                validarMutualExclusion();
            }
        });
        // Pasaporte
        txtPasaporte.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) {
                validarPasaporte();
                validarMutualExclusion();
            }
        });
        // Teléfono
        txtTelefono.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { validarTelefono(); }
        });
        // Código Postal
        txtCodigoPostal.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { validarCodigoPostal(); }
        });
        // Domicilio
        txtDomicilio.addFocusListener(new FocusAdapter() {
            public void focusLost(FocusEvent e) { validarDomicilio(); }
        });
    }

    // ── 6. Mutua exclusión DNI / Pasaporte ────────────────────────────────

    private void configurarMutualExclusion() {
        // Cuando el usuario empieza a escribir en DNI → deshabilitar Pasaporte
        txtDni.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e)  { actualizarEstadoPasaporte(); }
            public void removeUpdate(DocumentEvent e)  { actualizarEstadoPasaporte(); }
            public void changedUpdate(DocumentEvent e) { actualizarEstadoPasaporte(); }
        });
        // Cuando el usuario empieza a escribir en Pasaporte → deshabilitar DNI
        txtPasaporte.getDocument().addDocumentListener(new DocumentListener() {
            public void insertUpdate(DocumentEvent e)  { actualizarEstadoDni(); }
            public void removeUpdate(DocumentEvent e)  { actualizarEstadoDni(); }
            public void changedUpdate(DocumentEvent e) { actualizarEstadoDni(); }
        });
    }

    private void actualizarEstadoPasaporte() {
        boolean dniTieneContenido = !txtDni.getText().trim().isEmpty();
        txtPasaporte.setEnabled(!dniTieneContenido);
        if (dniTieneContenido) {
            txtPasaporte.setText("");
            lblErrorPasaporte.setText(" ");
            setBordeNormal(txtPasaporte);
        }
    }

    private void actualizarEstadoDni() {
        boolean pasaporteTieneContenido = !txtPasaporte.getText().trim().isEmpty();
        txtDni.setEnabled(!pasaporteTieneContenido);
        if (pasaporteTieneContenido) {
            txtDni.setText("");
            lblErrorDni.setText(" ");
            setBordeNormal(txtDni);
        }
    }

    // ── 7. Reglas de validación individuales ──────────────────────────────

    private boolean validarNombre() {
        String valor = txtNombre.getText().trim();
        if (valor.isEmpty()) {
            mostrarError(txtNombre, lblErrorNombre, "El nombre es obligatorio.");
            return false;
        }
        mostrarOk(txtNombre, lblErrorNombre);
        return true;
    }

    private boolean validarApellido() {
        String valor = txtApellido.getText().trim();
        if (valor.isEmpty()) {
            mostrarError(txtApellido, lblErrorApellido, "El apellido es obligatorio.");
            return false;
        }
        mostrarOk(txtApellido, lblErrorApellido);
        return true;
    }

    private boolean validarDni() {
        if (!txtDni.isEnabled()) { setBordeNormal(txtDni); lblErrorDni.setText(" "); return true; }
        String valor = txtDni.getText().trim();
        if (valor.isEmpty() && txtPasaporte.getText().trim().isEmpty()) {
            mostrarError(txtDni, lblErrorDni, "DNI o Pasaporte es obligatorio.");
            return false;
        }
        if (valor.isEmpty()) { setBordeNormal(txtDni); lblErrorDni.setText(" "); return true; }
        if (valor.length() != 8) {
            mostrarError(txtDni, lblErrorDni, "El DNI debe tener exactamente 8 dígitos.");
            return false;
        }
        long numero;
        try { numero = Long.parseLong(valor); }
        catch (NumberFormatException ex) {
            mostrarError(txtDni, lblErrorDni, "DNI inválido.");
            return false;
        }
        if (numero < 10_000_000 || numero > 60_000_000) {
            mostrarError(txtDni, lblErrorDni, "El DNI debe estar entre 10.000.000 y 60.000.000.");
            return false;
        }
        mostrarOk(txtDni, lblErrorDni);
        return true;
    }

    private boolean validarPasaporte() {
        if (!txtPasaporte.isEnabled()) { setBordeNormal(txtPasaporte); lblErrorPasaporte.setText(" "); return true; }
        String valor = txtPasaporte.getText().trim();
        if (valor.isEmpty() && txtDni.getText().trim().isEmpty()) {
            mostrarError(txtPasaporte, lblErrorPasaporte, "DNI o Pasaporte es obligatorio.");
            return false;
        }
        if (valor.isEmpty()) { setBordeNormal(txtPasaporte); lblErrorPasaporte.setText(" "); return true; }
        // Formato: 1 letra + 8 dígitos = 9 caracteres
        if (!valor.matches("[A-Za-z]\\d{8}")) {
            mostrarError(txtPasaporte, lblErrorPasaporte,
                    "Formato inválido. Ej: N39392288 (1 letra + 8 dígitos).");
            return false;
        }
        // Validar rango numérico (los 8 dígitos)
        long numero = Long.parseLong(valor.substring(1));
        if (numero < 10_000_000 || numero > 60_000_000) {
            mostrarError(txtPasaporte, lblErrorPasaporte,
                    "La parte numérica debe estar entre 10.000.000 y 60.000.000.");
            return false;
        }
        mostrarOk(txtPasaporte, lblErrorPasaporte);
        return true;
    }

    private boolean validarTelefono() {
        String valor = txtTelefono.getText().trim();
        if (valor.isEmpty()) {
            mostrarError(txtTelefono, lblErrorTelefono, "El teléfono es obligatorio.");
            return false;
        }
        // Extraer solo dígitos para verificar la cantidad mínima
        String soloDigitos = valor.replaceAll("[^0-9]", "");
        if (soloDigitos.length() <= 6) {
            mostrarError(txtTelefono, lblErrorTelefono,
                    "El teléfono debe tener más de 6 dígitos numéricos.");
            return false;
        }
        mostrarOk(txtTelefono, lblErrorTelefono);
        return true;
    }

    private boolean validarCodigoPostal() {
        String valor = txtCodigoPostal.getText().trim();
        if (valor.isEmpty()) {
            mostrarError(txtCodigoPostal, lblErrorCodigoPostal, "El código postal es obligatorio.");
            return false;
        }
        if (valor.length() != 4) {
            mostrarError(txtCodigoPostal, lblErrorCodigoPostal,
                    "El código postal debe tener exactamente 4 dígitos.");
            return false;
        }
        mostrarOk(txtCodigoPostal, lblErrorCodigoPostal);
        return true;
    }

    private boolean validarDomicilio() {
        String valor = txtDomicilio.getText().trim();
        if (valor.isEmpty()) {
            mostrarError(txtDomicilio, lblErrorDomicilio, "El domicilio es obligatorio.");
            return false;
        }
        mostrarOk(txtDomicilio, lblErrorDomicilio);
        return true;
    }

    private boolean validarMutualExclusion() {
        String dni = txtDni.getText().trim();
        String pasaporte = txtPasaporte.getText().trim();
        if (!dni.isEmpty() && !pasaporte.isEmpty()) {
            mostrarError(txtDni, lblErrorDni, "Solo puede completar DNI o Pasaporte, no ambos.");
            mostrarError(txtPasaporte, lblErrorPasaporte, "Solo puede completar DNI o Pasaporte, no ambos.");
            return false;
        }
        return true;
    }

    // ── 8. Validación completa del formulario (botón Validar) ─────────────

    private void validarFormulario() {
        boolean ok = true;
        ok &= validarNombre();
        ok &= validarApellido();
        ok &= validarDni();
        ok &= validarPasaporte();
        ok &= validarMutualExclusion();
        ok &= validarTelefono();
        ok &= validarCodigoPostal();
        ok &= validarDomicilio();

        if (ok) {
            JOptionPane.showMessageDialog(this,
                    "✔ Formulario válido.\nContacto cargado correctamente.",
                    "Éxito", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "⚠ Hay errores en el formulario.\nRevise los campos marcados en rojo.",
                    "Errores de validación", JOptionPane.WARNING_MESSAGE);
        }
    }

    // ── 9. Limpiar formulario ─────────────────────────────────────────────

    private void limpiarFormulario() {
        JTextField[] campos = {txtNombre, txtApellido, txtDni, txtPasaporte,
                               txtTelefono, txtCodigoPostal, txtDomicilio};
        JLabel[] errores = {lblErrorNombre, lblErrorApellido, lblErrorDni, lblErrorPasaporte,
                            lblErrorTelefono, lblErrorCodigoPostal, lblErrorDomicilio};

        for (JTextField campo : campos) {
            campo.setText("");
            campo.setEnabled(true);
            setBordeNormal(campo);
        }
        for (JLabel error : errores) {
            error.setText(" ");
        }
        txtNombre.requestFocus();
    }

    // ── 10. Helpers visuales ──────────────────────────────────────────────

    private void mostrarError(JTextField campo, JLabel labelError, String mensaje) {
        labelError.setText(mensaje);
        labelError.setForeground(COLOR_ERROR);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDE_ERROR, 2, true),
                new EmptyBorder(3, 5, 3, 5)
        ));
    }

    private void mostrarOk(JTextField campo, JLabel labelError) {
        labelError.setText("✔");
        labelError.setForeground(COLOR_OK);
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDE_OK, 2, true),
                new EmptyBorder(3, 5, 3, 5)
        ));
    }

    private void setBordeNormal(JTextField campo) {
        campo.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(COLOR_BORDE_NORMAL, 1, true),
                new EmptyBorder(3, 5, 3, 5)
        ));
    }

    // ── Clase interna: filtro de longitud máxima genérico ─────────────────

    static class FiltroMaxLength extends javax.swing.text.DocumentFilter {
        private final int max;
        FiltroMaxLength(int max) { this.max = max; }

        @Override
        public void insertString(FilterBypass fb, int offset, String string,
                                 javax.swing.text.AttributeSet attr)
                throws javax.swing.text.BadLocationException {
            if (string == null) return;
            if (fb.getDocument().getLength() + string.length() <= max)
                super.insertString(fb, offset, string, attr);
        }

        @Override
        public void replace(FilterBypass fb, int offset, int length, String text,
                            javax.swing.text.AttributeSet attrs)
                throws javax.swing.text.BadLocationException {
            if (text == null) return;
            int nuevaLong = fb.getDocument().getLength() - length + text.length();
            if (nuevaLong <= max)
                super.replace(fb, offset, length, text, attrs);
        }
    }
}
