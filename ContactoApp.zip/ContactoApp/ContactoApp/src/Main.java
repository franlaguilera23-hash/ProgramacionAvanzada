//Alumno:Aguilera Francisco
//Legajo: 114415

public class Main {
    public static void main(String[] args) {
        javax.swing.SwingUtilities.invokeLater(() -> {
            FormularioContacto formulario = new FormularioContacto();
            formulario.setVisible(true);
        });
    }
}
