import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 * Filtro que solo permite dígitos numéricos.
 * Usado para los campos DNI y Código Postal.
 */
public class FiltroNumerico extends DocumentFilter {

    private final int maxCaracteres;

    public FiltroNumerico(int maxCaracteres) {
        this.maxCaracteres = maxCaracteres;
    }

    @Override
    public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
            throws BadLocationException {
        if (string == null) return;
        String filtrado = filtrar(string);
        if (fb.getDocument().getLength() + filtrado.length() <= maxCaracteres) {
            super.insertString(fb, offset, filtrado, attr);
        }
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
            throws BadLocationException {
        if (text == null) return;
        String filtrado = filtrar(text);
        int longitudActual = fb.getDocument().getLength();
        int nuevaLongitud = longitudActual - length + filtrado.length();
        if (nuevaLongitud <= maxCaracteres) {
            super.replace(fb, offset, length, filtrado, attrs);
        }
    }

    private String filtrar(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            if (Character.isDigit(c)) {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
