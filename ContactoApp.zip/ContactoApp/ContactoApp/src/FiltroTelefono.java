import javax.swing.text.AttributeSet;
import javax.swing.text.BadLocationException;
import javax.swing.text.DocumentFilter;

/**
 * Filtro para el campo Teléfono.
 * Permite dígitos numéricos y los caracteres especiales: + ( ) - y espacio.
 * Ejemplo válido: +54 9 (261)-5-012345
 */
public class FiltroTelefono extends DocumentFilter {

    private static final int MAX_LONGITUD = 20;

    @Override
    public void insertString(FilterBypass fb, int offset, String string, AttributeSet attr)
            throws BadLocationException {
        if (string == null) return;
        String filtrado = filtrar(string);
        if (fb.getDocument().getLength() + filtrado.length() <= MAX_LONGITUD) {
            super.insertString(fb, offset, filtrado, attr);
        }
    }

    @Override
    public void replace(FilterBypass fb, int offset, int length, String text, AttributeSet attrs)
            throws BadLocationException {
        if (text == null) return;
        String filtrado = filtrar(text);
        int longitudActual = fb.getDocument().getLength();
        int nuevaLongitud = longitudActual - length + filtrado.length();
        if (nuevaLongitud <= MAX_LONGITUD) {
            super.replace(fb, offset, length, filtrado, attrs);
        }
    }

    private String filtrar(String texto) {
        StringBuilder sb = new StringBuilder();
        for (char c : texto.toCharArray()) {
            if (Character.isDigit(c) || c == '+' || c == '(' || c == ')' || c == '-' || c == ' ') {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
